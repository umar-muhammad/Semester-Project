import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
 
public class UserStore {
 
    private static final Path FILE = Paths.get("users.txt");
 
    private final HashMap<String, String[]> users = new HashMap<>();
 
    public UserStore() {
        load();
    }
 
    private void load() {
        if (!Files.exists(FILE)) {
            return;
        }
        try {
            List<String> lines = Files.readAllLines(FILE, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    users.put(parts[0], new String[]{parts[1], parts[2]});
                }
            }
        } catch (IOException e) {
            System.out.println("Could not read " + FILE + ": " + e.getMessage());
        }
    }
 
    public boolean userExists(String username) {
        return users.containsKey(username.toLowerCase());
    }
 
    public boolean register(String username, String password) {
        String key = username.toLowerCase();
        if (users.containsKey(key)) {
            return false;
        }
 
        String salt = newSalt();
        String hash = hash(password, salt);
        String line = key + "," + salt + "," + hash + System.lineSeparator();
 
        try {
            Files.write(FILE, line.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("Could not save account: " + e.getMessage());
            return false;
        }
 
        users.put(key, new String[]{salt, hash});
        return true;
    }
 
    public boolean checkPassword(String username, String password) {
        String[] record = users.get(username.toLowerCase());
        if (record == null) {
            return false;
        }
        String attempt = hash(password, record[0]);
        return MessageDigest.isEqual(
                attempt.getBytes(StandardCharsets.UTF_8),
                record[1].getBytes(StandardCharsets.UTF_8));
    }
 
    private String newSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }
 
    // PBKDF2 is built into Java, so no extra library is needed
    private String hash(String password, String salt) {
        try {
            byte[] saltBytes = Base64.getDecoder().decode(salt);
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), saltBytes, 65536, 256);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return Base64.getEncoder().encodeToString(factory.generateSecret(spec).getEncoded());
        } catch (Exception e) {
            throw new RuntimeException("Password hashing failed", e);
        }
    }
}
